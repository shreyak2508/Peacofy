public class test116 {
    public static void main(String[] args) {
        String name="yash";
        String fame="ashture";


        if(name.campreTo(fame)){
            System.out.println("The Strings are equal");
        }else
        System.out.println("String are not equal");
        
    }
    
}
